import React, { Component } from "react";
import {
  Image,
  Text,
  View,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  Button,
  SafeAreaView,
  TextInput,
} from "react-native";
import Header from "../../components/Header";
import ButtonTouchable from "../../components/ButtonTouchable";
import BackButton from "../../components/BackButton";
import LogoText from "../../components/LogoText";
import SearchButton from "../../components/SearchButton";
import Input from "../../components/Input";
import Footer from "../../components/Footer";
import Svg, { Path } from "react-native-svg";
import { RadioButton, Checkbox } from "react-native-paper";
import styles from "./styles";

const image = require("../../assets/img/texture__sections.png");

const logoIcon = require("../../assets/img/icon__questionnaire-title.png");

export default class DashboardQuestions extends React.Component {
  render() {
    return (
      <View style={styles.mainBody}>
        <ScrollView>
          <View style={styles.topActions}>
            <BackButton />
            <SearchButton />
          </View>
          <Header />
          <LogoText source={logoIcon} text={"questionaries"} />
          <SafeAreaView style={styles.container}>
            <View style={styles.menuSections}>
              <View style={[styles.singleMenu, styles.customSection]}>
                <View style={[styles.menutopDot, styles.currentActive]}></View>
                <Text style={[styles.menuText, styles.currentActive]}>
                  section A
                </Text>
              </View>
              <View style={styles.singleMenu}>
                <View style={styles.menutopDot}></View>
                <Text style={styles.menuText}>section B</Text>
              </View>
              <View style={styles.singleMenu}>
                <View style={styles.menutopDot}></View>
                <Text style={styles.menuText}>section C</Text>
              </View>
              <View style={styles.singleMenu}>
                <View style={styles.menutopDot}></View>
                <Text style={styles.menuText}>section D</Text>
              </View>
            </View>

            <View style={styles.referredSection}>
              <Text style={styles.referredByTxt}>
                1. My child was referred by
              </Text>
            </View>
            <View style={styles.referredBy}>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>
                  Parent or legal guardian
                </Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>GP</Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Medical consultant</Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Public health nurse</Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Teacher</Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>
                  Preschool or Montessori leader
                </Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Creche</Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Others</Text>
              </View>
              <View style={styles.referredByOther}>
                <Input placeholder="Please enter the name of the referrer..." />
              </View>
            </View>
            <View style={styles.referredSection}>
              <Text style={styles.referredByTxt}>
                2. What is your child's name?
              </Text>
              <View style={styles.childNameInput}>
                <View style={styles.childFirstName}>
                  <Input placeholder="First Name" />
                </View>

                <View style={styles.childLastName}>
                  <Input placeholder="Last Name" />
                </View>
              </View>
              <Input placeholder="hello" />
            </View>
            <View style={styles.referredSection}>
              <Text style={styles.referredByTxt}>3. Gender</Text>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Male</Text>
              </View>
              <View style={styles.referredFrom}>
                <RadioButton style={styles.radioBtnIcon} />
                <Text style={styles.referredFromTxt}>Female</Text>
              </View>
            </View>

            <View style={styles.continueBtn}>
              <ButtonTouchable text={"continue"} />
            </View>
            <View style={styles.multiTabBottomUl}>
              <View
                style={[styles.multiTabBottomLi, styles.currentActiveBottom]}
              ></View>
              <View style={styles.multiTabBottomLi}></View>
              <View style={styles.multiTabBottomLi}></View>
              <View style={styles.multiTabBottomLi}></View>
            </View>
            <View style={{ paddingTop: 80 }}></View>
          </SafeAreaView>
        </ScrollView>

        {/* <Footer /> */}
      </View>
    );
  }
}
