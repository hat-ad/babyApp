import React from "react";
import { View, Text } from "react-native";
import styles from "./styles";

const x = () => {
  return (
    <View>
      <Text style={styles.x}>This is a diffrent page</Text>
    </View>
  );
};

export default x;
