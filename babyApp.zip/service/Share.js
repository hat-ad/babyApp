import Api from './Api';


export default class Share {

	static test = async () => {
	   
  	};

}
