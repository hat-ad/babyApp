import tokeys from 'tokeys';

export default tokeys([
	'TOKEN',
]);