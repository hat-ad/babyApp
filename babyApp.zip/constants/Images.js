import profile from '../assets/img/profile.png';
import GORDON3 from '../assets/img/GORDON3.jpg';
import GORDON4 from '../assets/img/GORDON4.jpg';


export {
  profile,
  GORDON3,
  GORDON4
};
